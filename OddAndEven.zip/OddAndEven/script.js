alert("Enter a number to show that the number is Odd or Even");

var num;

num = prompt("Enter the number");

if(num % 2 == 0){
    document.write("<h1>" + num + " is an Even number</h1>");
}
else{
    document.write("<h1>" + num + " is an Odd number</h1>");
}